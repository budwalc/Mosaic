Created by Charandeep Singh Budwal - 2019/04/09

Please find my 1st attempt of the text exercise of creating the To-Do List.


1. I've enabled all functionality except the Checkbox, I've had some problems tackling the issue of STRIKETHOUGH text within <li> items when clicking on the checkbox. I assume I'm overthinking it, instead I've created a click event when clicking on the <li> text which will create a strikethough instead.
2. Any questions, please feel free to contact me on 07525759843 / budwalc@gmail.com

Thank You Kindly.

Chaz Budwal
